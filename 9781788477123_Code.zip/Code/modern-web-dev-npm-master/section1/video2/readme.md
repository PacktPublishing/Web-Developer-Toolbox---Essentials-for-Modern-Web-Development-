```
npm install -g emoji-cli

emoji rocket

npm uninstall -g emoji-cli

npm install —save-dev emoji-cli

ls node_modules/.bin

node_modules/.bin/emoji tennis

```
