# Commands

```
npm init

npm install lodash

# add index.js file
with code

const _ = require('lodash')

console.log(_.random(100))


node index.js

ls -ltr node_modules

rm -rf node_modules

ls node_modules

node index.js # <- broken

# Directory specific command

npm install

ls node_modules

node index.js

npm install --save-dev chalk

# Add code to index.js


const chalk = require('chalk')

console.log(chalk.blue('I am blue!'))
```
