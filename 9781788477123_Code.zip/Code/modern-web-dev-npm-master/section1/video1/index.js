const _ = require('lodash')

console.log(_.random(100))


const chalk = require('chalk')

console.log(chalk.blue('I am blue!'))
