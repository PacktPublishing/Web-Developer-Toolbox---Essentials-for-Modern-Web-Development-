```
# Add into scripts in package.json:

"say:hello": "echo 'hello'"

npm run say:hello

npm install —save-dev emoji-cli

# Add into scripts in package.json:

"emoji": "emoji dog"

npm run emoji

```
