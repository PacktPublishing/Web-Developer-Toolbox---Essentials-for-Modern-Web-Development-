```
npm install lodash
npm install react
npm install react-dom
npm install moment
npm install redux

```
