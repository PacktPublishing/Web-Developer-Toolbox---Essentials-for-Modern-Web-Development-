import React from 'react';
import { render } from 'react-dom';
// import './lodashExamples'
// import './momentExamples'
import './httpExamples'

render(<h1>Hello world!</h1>, document.getElementById('root'));
