```
.container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.flex {
  display: flex;
  flex: 1;
}
```
