import './styles/myStyle.scss'
