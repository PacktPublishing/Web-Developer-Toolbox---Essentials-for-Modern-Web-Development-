console.log('Hello');

const funfunfun = (x,y,z) => {
  if (true) {
    return z
  }
}
