export default () => (
  <div>About us</div>
)
