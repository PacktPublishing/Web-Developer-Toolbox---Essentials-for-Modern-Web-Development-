import _ from 'lodash'

export const printRandom = () => console.log(_.random(1, 100))
