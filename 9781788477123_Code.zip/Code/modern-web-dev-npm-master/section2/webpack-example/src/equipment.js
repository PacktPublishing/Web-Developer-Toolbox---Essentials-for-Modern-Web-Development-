export const keyboard = () => 'keyboard'

export const mouse = () => 'mouse'
